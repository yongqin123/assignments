###def a():
###    print("Hello World")
###
###a()
