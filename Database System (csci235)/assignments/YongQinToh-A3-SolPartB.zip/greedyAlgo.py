import re
from itertools import combinations

def print_powerset(string):
  array = []
  for i in range(0,len(string)+1):
    for element in combinations(string,i):
      array.append(list(element))
  array = array[1:]
  
  array2 = filter(lambda x: len(x) == 2, array)
  array2 = list(array2)
  array3 = []
  for i in array2:
    array3.append(i)
    [a,b] = i
    array3.append([b,a])

  #print(list(array3))
  array1 = filter(lambda x: len(x) == 1 , array)
  
  array1 = list(array1)
  for i in range(len(list(array1))):
    array1[i].append(array1[i][0])
  #print(array1)
  return array3+array1

##Prpgram starts here##
with open('A3Data.txt') as f:
    lines = f.read()


array = re.split(r"[\s, ]",lines)

while "" in array:
    array.remove("")

number_of_students = array[1] 
array = array[1:]
dummy = []
list_of_students = []

i = 0
while i < len(array):
    if array[i].isnumeric():
        integer = int(array[i])
        for j in range(1,integer+1):
            dummy.append(array[i+j])
        list_of_students.append(dummy)
        dummy = []
        i = integer +i
    else:
        i+=1


matrix = []
dum = []
for i in range(7):
    for j in range(7):
        dum.append(0)
    matrix.append(dum)
    dum = []


'''
csci203,204,205,212,213,222,235
csci204
    205
    212
    213
    222
    235
  
'''

dictionary = {'CSCI203':0,'CSCI204':1,'CSCI205':2,'CSCI212':3,'CSCI213':4,'CSCI222':5,'CSCI235':6}

for i in list_of_students:
    new_arr1 = []
    new_arr2 = []
    for j in i:
        new_arr1.append(dictionary[j])
    permutation_sets = print_powerset(new_arr1)
    
    for k in permutation_sets:
        [a,b] = k
        matrix[a][b] += 1


new_matrix = []
for i in matrix:
    new_matrix.append(i.count(0))

new_dic = {}
for i in range(len(new_matrix)):
    new_dic[list(dictionary.keys())[i]] = new_matrix[i]
 
sorted_array = sorted(new_dic.items(), key=lambda x: x[1], reverse=True)


timeslots = []
index = 0
while (len(sorted_array) != 0):
  if len(sorted_array) == 1:
    timeslots.append([sorted_array[0][0]])
    break
  else:
    
    ar = [sorted_array[i][0] for i in range(len(sorted_array))]
    e = sorted_array[0]
    f = min(dict(sorted_array), key=dict(sorted_array).get)
    for j in ar[ar.index(f):]:
      for i in list_of_students:
        if sorted_array[0][0] in i and j in i:
          break
        if i == list_of_students[-1]:
          
          timeslots.append([sorted_array[0][0],ar[ar.index(j)]])
          sorted_array.pop(ar.index(j))
          sorted_array = sorted_array[1:]
          ar.pop(ar.index(j))
          ar = ar[1:]
          break
    
counter = []

for i in timeslots:
  count = 0
  
  for k in list_of_students:
    if (i[0] in k):
      count+=1
    if (len(i)>1):
      if (i[1] in k):
        count+=1
  counter.append(count)

for i in range(len(timeslots)):
  if len(timeslots[i])>1:
    print(f"Slot {(i+1)}: {timeslots[i][0]}, {timeslots[i][1]}      {counter[i]}")
  else:
    print(f"Slot {(i+1)}: {timeslots[i][0]}               {counter[i]}")
