Python 3.9.5 (tags/v3.9.5:0a7dcbd)

Run on IDLE Shell 3.9.5

